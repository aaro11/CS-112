<?php
$link = mysql_connect("localhost:3306","user1","pass1");
if(!$link) {
    die('Could not connect: ' . mysql_error());
}
//echo 'Successfully connected';
mysql_select_db("droid_project");
$sql=mysql_query("select * from Post where Postnum like '%'");
while($row=mysql_fetch_assoc($sql)){
$output[]=$row;
}
print(json_encode($output));
//echo 'END';
mysql_close($link);
?>
