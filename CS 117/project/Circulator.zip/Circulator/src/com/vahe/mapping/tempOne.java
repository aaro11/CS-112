package com.vahe.mapping;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class tempOne extends Activity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.color_code1);
		
		//set up my edit texts
		final EditText res1=(EditText) findViewById(R.id.editText1);
		final EditText voltage=(EditText) findViewById(R.id.editText2);
		final EditText result=(EditText) findViewById(R.id.editText7);
		
		Button b1=(Button)findViewById(R.id.button2);
        b1.setOnClickListener(new OnClickListener() {
        	
        	public void onClick(View v) {
        	// TODO Auto-generated method stub	
        		String s1=res1.getText().toString();
        		String s2=voltage.getText().toString();
        		
        		if (s1.contentEquals("") || s2.contentEquals("")) 
        			startActivity(new Intent("com.vahe.mapping.INTERRUPT"));
        		else
        		{
        			if (Double.parseDouble(s1)==0) Toast.makeText(tempOne.this, "The resistance cannot be 0", Toast.LENGTH_LONG).show();
					else 
					{
						int a=new Double(Double.parseDouble(s2)/Double.parseDouble(s1)).toString().length();
						
						if (a<6)	result.setText(new Double(Double.parseDouble(s2)/Double.parseDouble(s1)).toString());
						else	result.setText(new Double(Double.parseDouble(s2)/Double.parseDouble(s1)).toString().substring(0, 6));
					}
        		}
        	}
        });
	}
}

