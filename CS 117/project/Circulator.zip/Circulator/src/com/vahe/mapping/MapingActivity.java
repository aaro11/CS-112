package com.vahe.mapping;

import java.util.List;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.Toast;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.MyLocationOverlay;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;

public class MapingActivity extends MapActivity {
    @Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		compass.disableCompass();
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		compass.enableCompass();
	}
	
    MapView map;
	long start;
	long stop;
	MyLocationOverlay compass;
	MapController controller;
	int i=1;
	private GeoPoint currentPoint;
	private LocationManager locationManager;
	private Location currentLocation = null;
	private String[] location=new String[] {
			"Target", "421 Arden Ave # C, Glendale, CA ", 
			"Office Depot", "515 West Broadway, Glendale, CA", 
			"Apple", "Americana, Glendale, CA",  
			"GameStop", "3216 Glendale Galleria, Space Hu-3, Glendale, CA",  
			"BestBuy", "2909 Los Feliz Boulevard, Los Angeles, CA", 
			"Bel-Air Camera Superstore", "10925 Kinross Avenue, Los Angeles, CA",  
			"RadioShack", "1051 Westwood Boulevard, Los Angeles, CA",  
			"BestBuy", "10861 Weyburn Avenue, Los Angeles, CA", 
	};
	private int[] address=new int[] {
			(int)(34.143138*1e6), (int)(-118.258553*1e6),
			(int)(34.147453*1e6), (int)(-118.26544*1e6),
			(int)(34.14589*1e6), (int)(-118.256814*1e6),
			(int)(34.142508*1e6), (int)(-118.255075*1e6),
			(int)(34.127668*1e6), (int)(-118.265247*1e6),
			(int)(34.06043*1e6), (int)(-118.446294*1e6),
			(int)(34.061595*1e6), (int)(-118.445338*1e6),
			(int)(34.062416*1e6), (int)(-118.443482*1e6),
	};
	private Integer[] draw=new Integer[] {
		R.drawable.target, R.drawable.office, R.drawable.apple, R.drawable.gameboy,
		R.drawable.bestbuy, R.drawable.camera, R.drawable.radioshack, R.drawable.bestbuy,
	};
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.map);
        map=(MapView)findViewById(R.id.mapview);
        map.setBuiltInZoomControls(true);
        map.displayZoomControls(true); 
    
        final MyLocationOverlay myLocationOverlay = new MyLocationOverlay(this, map); 
        map.getOverlays().add(myLocationOverlay); 
        myLocationOverlay.enableMyLocation(); 
        if (myLocationOverlay.getMyLocation() != null) {
        	  myLocationOverlay.runOnFirstFix(new Runnable() { 
        		  public void run() {
        			  map.getController().animateTo(myLocationOverlay.getMyLocation());                
        		  }
        	  });
        }
//////////////////////////////////////////////////////////////////////////////////////////////
        for (; i<9; i++) {
            addGeoPoint(address[2*i-2], address[2*i-1], location[2*i-2], location[2*i-1], draw[i-1]);
        }
//////////////////////////////////////////////////////////////////////////////////////////////        
        compass = new MyLocationOverlay(this, map);
        map.getOverlays().add(compass);
        controller=map.getController();
        controller.setZoom(14);
        getLastLocation();
        animateToCurrentLocation();   
    }
	
	public static Drawable boundCenter(Drawable d)
	{
	     d.setBounds(d.getIntrinsicWidth() /- 2, d.getIntrinsicHeight() / -2,
	                 d.getIntrinsicWidth() / 2, d.getIntrinsicHeight() / 2);
	     return d;
	}

	public void getLastLocation() {
	    String provider = getBestProvider();
	    currentLocation = locationManager.getLastKnownLocation(provider);
	    if(currentLocation != null)	setCurrentLocation(currentLocation);
	    else	Toast.makeText(this, "Location not yet acquired", Toast.LENGTH_LONG).show();
	}
	 
	public void animateToCurrentLocation(){
	    if(currentPoint!=null){
	        controller.animateTo(currentPoint);
	    }
	}
	 
	public String getBestProvider(){
	    locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
	    Criteria criteria = new Criteria();
	    criteria.setPowerRequirement(Criteria.NO_REQUIREMENT);
	    criteria.setAccuracy(Criteria.NO_REQUIREMENT);
	    String bestProvider = locationManager.getBestProvider(criteria, true);
	    return bestProvider;
	}
	 
	public void setCurrentLocation(Location location){
	    int currLatitude = (int) (location.getLatitude()*1E6);
	    int currLongitude = (int) (location.getLongitude()*1E6);
	    currentPoint = new GeoPoint(currLatitude,currLongitude);
	    currentLocation = new Location("");
	    currentLocation.setLatitude(currentPoint.getLatitudeE6() / 1e6);
	    currentLocation.setLongitude(currentPoint.getLongitudeE6() / 1e6);
	}
	
	@Override
	protected boolean isRouteDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}
	
	private void addGeoPoint(int a, int b, String name, String address, Integer picture) {
		
		List<Overlay> mapOverlays = map.getOverlays();
        Drawable drawable = this.getResources().getDrawable(picture);
        boundCenter(drawable);        
        HelloItemizedOverlay itemizedoverlay = new HelloItemizedOverlay(drawable, this);
        GeoPoint point = new GeoPoint(a,b);
        OverlayItem overlayitem = new OverlayItem(point, name, address);
        itemizedoverlay.addOverlay(overlayitem);
        mapOverlays.add(itemizedoverlay);
	}
}