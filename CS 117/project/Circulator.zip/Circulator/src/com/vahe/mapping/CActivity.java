package com.vahe.mapping;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class CActivity extends Activity {
    /** Called when the activity is first created. */
	
	MediaPlayer sound_b;
	Button start_b;
	Button about_b;
	Button stores_b;
	Button forum_b;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main); 
   
        //set up sound for our button
        sound_b=MediaPlayer.create(this, R.raw.sonund);
        //set up our button
    	start_b=(Button) findViewById(R.id.start);
    	about_b=(Button) findViewById(R.id.about);
    	stores_b=(Button) findViewById(R.id.location);
    	forum_b=(Button) findViewById(R.id.forum);
    	start_b.setOnClickListener(new View.OnClickListener() {
    		public void onClick(View v) {
    			sound_b.start();
    			startActivity(new Intent("com.vahe.mapping.START"));
    		}
    		    		
    	});
    	about_b.setOnClickListener(new View.OnClickListener() {
    		public void onClick(View v) {
    			sound_b.start();
    			startActivity(new Intent("com.vahe.mapping.ABOUT"));
    		}
    		    		
    	});
    	stores_b.setOnClickListener(new View.OnClickListener() {
    		public void onClick(View v) {
    			sound_b.start();
    			startActivity(new Intent("com.vahe.mapping.MAP"));
    		}
    		    		
    	});
    	forum_b.setOnClickListener(new View.OnClickListener() {
    		public void onClick(View v) {
    			sound_b.start();
    			startActivity(new Intent("com.vahe.mapping.FWARN"));
    			//startActivity(new Intent("com.vahe.mapping.FORUM"));
    		}
    		    		
    	});
    }
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
	}
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
	}
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
	}
	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
	}
	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
	}
}
