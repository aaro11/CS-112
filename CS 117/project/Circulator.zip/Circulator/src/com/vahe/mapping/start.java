package com.vahe.mapping;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class start extends Activity {

	ImageButton temp1;
	ImageButton temp2;
	ImageButton temp3;
	ImageButton temp4;
	MediaPlayer sound;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.temp_screen);
		
		//set up sound for our button
        sound=MediaPlayer.create(this, R.raw.sonund);
        //set up our button
    	temp1=(ImageButton) findViewById(R.id.imageButton1);
    	temp2=(ImageButton) findViewById(R.id.imageButton2);
    	temp3=(ImageButton) findViewById(R.id.imageButton3);
    	temp4=(ImageButton) findViewById(R.id.imageButton4);
    	
    	temp1.setOnClickListener(new View.OnClickListener() {
    		public void onClick(View v) {
    			sound.start();
    			startActivity(new Intent("com.vahe.mapping.TEMP1"));
    		}
    		    		
    	});
    	temp2.setOnClickListener(new View.OnClickListener() {
    		public void onClick(View v) {
    			sound.start();
    			startActivity(new Intent("com.vahe.mapping.TEMP2"));
    		}
    		    		
    	});
    	temp3.setOnClickListener(new View.OnClickListener() {
    		public void onClick(View v) {
    			sound.start();
    			startActivity(new Intent("com.vahe.mapping.TEMP3"));
    		}
    		    		
    	});
    	temp4.setOnClickListener(new View.OnClickListener() {
    		public void onClick(View v) {
    			sound.start();
    			startActivity(new Intent("com.vahe.mapping.TEMP4"));
    		}
    		    		
    	});
	}
}

