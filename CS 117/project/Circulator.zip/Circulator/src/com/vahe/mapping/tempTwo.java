package com.vahe.mapping;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class tempTwo extends Activity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.color_code2);
		
		//set up my edit texts
		final EditText res1=(EditText) findViewById(R.id.editText1);
		final EditText res2=(EditText) findViewById(R.id.editText5);
		final EditText res3=(EditText) findViewById(R.id.editText3);
		final EditText voltage=(EditText) findViewById(R.id.editText4);
		final EditText result=(EditText) findViewById(R.id.editText7);
		
		Button b1=(Button)findViewById(R.id.button2);

        b1.setOnClickListener(new OnClickListener() {

        	public void onClick(View v) {            
				String a=res1.getText().toString();
				String b=res2.getText().toString();
				String c=res3.getText().toString();
				String d=voltage.getText().toString();
				
				if (a.contentEquals("") || b.contentEquals("") || 
						c.contentEquals("") || d.contentEquals("")) 
					startActivity(new Intent("com.vahe.mapping.INTERRUPT"));
				else
        		{
					if (Double.parseDouble(b)==0 || Double.parseDouble(c)==0)
		        		Toast.makeText(tempTwo.this, "R2 and R3 cannot be equal to 0", Toast.LENGTH_LONG).show();
					else 
					{
						double g=1/(1/Double.parseDouble(b)+1/Double.parseDouble(c))+Double.parseDouble(a);
						int size=new Double(Double.parseDouble(d)/g).toString().length();
        			
						if (size<6)	result.setText(new Double(Double.parseDouble(d)/g).toString());
						else	result.setText(new Double(Double.parseDouble(d)/g).toString().substring(0, 6));
        		
					}
        		}
		    }        	
		 });
				
	}
}

