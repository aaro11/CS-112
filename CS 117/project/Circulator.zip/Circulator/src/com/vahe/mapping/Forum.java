package com.vahe.mapping;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ListActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.net.ParseException;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Toast;

public class Forum extends ListActivity
{
    private static final int ADD_ITEM = 0;
    private static final int EXIT = 1;
 
    private ArrayAdapter<String> dataAdapter;
    private Dialog editorDialog = null;
    //private post=null;
    
    //variables for read/write from/to sql database
	JSONArray jArray;
	String result = null;
	InputStream is = null;
	StringBuilder sb=null;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        // This array list will be updated each time.
        final ArrayList<String> data = new ArrayList<String>();
        
        //sql array
        ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
    	
    	//http post
    	try
    	{
    	     HttpClient httpclient = new DefaultHttpClient();
    	     HttpPost httppost = new HttpPost("http://192.168.0.105/readsql.php");
    	     httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
    	     HttpResponse response = httpclient.execute(httppost);
    	     HttpEntity entity = response.getEntity();
    	     is = entity.getContent();
    	}
    	catch(Exception e)
    	{
    	     Log.e("log_tag", "Error in http connection"+e.toString());
    	}
    	
    	//convert response to string
    	try{
    	      BufferedReader reader = new BufferedReader(new InputStreamReader(is,"iso-8859-1"),8);
    	       sb = new StringBuilder();
    	       sb.append(reader.readLine() + "\n");

    	       String line="0";
    	       while ((line = reader.readLine()) != null) 
    	       {
    	                      sb.append(line + "\n");
    	       }
    	       is.close();
    	       result=sb.toString();
    	 }
    	catch(Exception e)
    	{
    		Log.e("log_tag", "Error converting result "+e.toString());
    	}
    	
    	//parsing data
    	String Pbody;
    	try
    	{
    	      jArray = new JSONArray(result);
    	      JSONObject json_data=null;
    	      
    	      for(int i=0;i<jArray.length();i++)
    	      {
    	             json_data = jArray.getJSONObject(i);
 //   	             int Pnum = json_data.getInt("Postnum");
    	             Pbody = json_data.getString("Body");
    	             data.add(Pbody);
    	             dataAdapter = new ArrayAdapter<String>(this, R.layout.item, R.id.itemName, data);
    	      }
    	 }
    	catch(JSONException e1)
    	{
    		Toast.makeText(getBaseContext(), "JSONexception" ,Toast.LENGTH_LONG).show();
    	}
    	catch (ParseException e1) 
    	{
    		e1.printStackTrace();
        }	
    	
        // This timer output will prove that items being added and removed to
        // our array list.
        Timer outer = new Timer();
        outer.schedule(new TimerTask()
        {

            @Override
            public void run()
            {
                Log.i("DATA:", "Start");
                for (String item : data)
                {
                    Log.i("DATA: ", item.toString());
                }
                Log.i("DATA: ", "finish");
            }
        }, 5000, 5000);

        setListAdapter(dataAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        Resources resource = getApplicationContext().getResources();
        menu.add(Menu.NONE, ADD_ITEM, ADD_ITEM,
            resource.getText(R.string.ADD_ITEM)).setIcon(R.drawable.add);
        menu.add(Menu.NONE, EXIT, EXIT,
            resource.getText(R.string.Exit)).setIcon(R.drawable.exit);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
        case ADD_ITEM:
            showDialog(0);
            break;
        case EXIT:
            dataAdapter.remove(dataAdapter.getItem(dataAdapter.getCount() - 1));
            break;
        }
        return false;
    }

    @Override
    protected Dialog onCreateDialog(int id)
    {
        Dialog editor = editorDialog;
        if (editorDialog == null)
        {
            editor = createEditorDialog();
        }
        return editor;
    }

    private Dialog createEditorDialog()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.addDialogTitle);

        View content = getLayoutInflater().inflate(R.layout.editor,
            (ViewGroup) findViewById(R.id.editLayout));
        builder.setView(content);
        builder.setPositiveButton(R.string.addButtonLabel,
            new DialogInterface.OnClickListener()
            {

                public void onClick(DialogInterface dialog, int which)
                {
                    Dialog source = (Dialog) dialog;
                    EditText nameField = (EditText) source
                        .findViewById(R.id.itemField);
                    String name = nameField.getText().toString();
                    ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();

                    if (name.length() > 0){
                    	dataAdapter.add(name);
                    	nameValuePairs.add(new BasicNameValuePair("Pbody",name));
                    	 try{
                    	        HttpClient httpclient = new DefaultHttpClient();
                    	        HttpPost httppost = new HttpPost("http://192.168.0.105/write2sql.php");
                    	        httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                    	        HttpResponse response = httpclient.execute(httppost);
                    	        HttpEntity entity = response.getEntity();
                    	        is = entity.getContent();
                    	        }catch(Exception e){
                    	        	Log.e("log_tag", "Error in http connection"+e.toString());
                    	        }
                  
                    }
                    dialog.dismiss();
                }
            });

        builder.setNegativeButton(R.string.cancelButtonLabel,
            new DialogInterface.OnClickListener()
            {

                public void onClick(DialogInterface dialog, int which)
                {
                    dialog.dismiss();
                }
            });

        return builder.create();
    }
}