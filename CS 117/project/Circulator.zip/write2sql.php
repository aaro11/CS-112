<?php
$link = mysql_connect("localhost:3306","dennis","pass1");
if(!$link) {
    die('Could not connect: ' . mysql_error());
}
echo 'START';
mysql_select_db("droid_project");
$sql=mysql_query("insert into Post values('', '".($_REQUEST['Pbody'])."' )");
if(!$sql)
echo "Error in query: ".mysql_error();
echo 'END';
mysql_close();
?>
